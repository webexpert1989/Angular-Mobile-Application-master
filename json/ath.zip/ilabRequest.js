/*
 * Structure of a Generic Request in iLAb 
 */


function Patient() {
    this.patName = "";
    this.patFirstName = "";
    this.patTitle = "";
    this.PatIntRef;
    this.patExtRef;
    this.patSocialSecurity;
    this.patCG1;
    this.patCG2;
    this.patGender = "";
    this.patBirthDate = "";
    this.patRRN = "";
    this.patAdress = new Adress();
    this.patContact = new Array();
    this.cliInformation = new ClinicalInfo();
}

function Prescriber() {
    this.presName = "";
    this.presFirstName = "";
    this.presIntRef = "";
    this.presExtRef = ""; 
    this.presRegNumber = "";
    this.presContact = new Array();
    this.presAdress = new Adress();
}


function AnalysesCode() {
    this.anaCodingSystem;
    this.anaCode;
    this.anaPaymentType = "";
    this.anaCodeDesc = "";
    this.anaCodePrice = "";
    this.samplRef;
}


function iLabRequest() {
    this.reqRef = "";       // referentie van de aanvraag 
    this.reqVersion = "";   // versie van deze aanvraag structuur 
    this.reqIntRef = "";    // ons aanvraag nummer 9xxx
    this.reqExtRef = "";     // hun aanvraagnummer 
    this.reqDate = "";      // datum van aanvraag 
    this.reqOrigin = "";    // origine van de aanvraag 
    this.reqUrgency = "";   // code die aangeeft hoe dringend de aanvraag is 
    this.reqLanguage = "";   // taal van gewenste rapport
    this.samples = new Array();   // Stalen 
    this.analyses = new Analyses();  // gevraagde analysen
    this.patient = new Patient();   // patient gegevens 
    this.prescriber = new Prescriber(); // aanvrager
    this.reqComments = "";  // opmerkingen bij de aanvraag 
}

function Analyses() {
    this.analysesCode = new Array(); // gevraagde analyse codes
    this.anaComment = "";   // extra analyses die niet opgenomen zijn in ons aanvraagformulier
}

function Adress() {
    this.adrStreet = "";
    this.adrSecondLine = "";
    this.adrZip = "";
    this.adrCity = "";
    this.adrCountry = "";
}

function Sample() {
    this.samplIntRef;  // Onze referentie = onze barcode
    this.samplExtRef;  // hun referenctie 
    this.samplMatrix;  // matrix 
    this.samplDate;    // datum van het het staal 
    this.sampleCount;  // aantal stalen die ze meegeven van die Matrix
    this.samplComments; // vrije comentaar

}

function Contact() {
    this.cntType = "";  // Patient, Prescriber, Other 
    this.cntName = ""; // Naam van het contact
    this.cntProvider; // Fax , email, phone , electronic
    this.cntProviderInfo; // connect string
    this.cntAdress = new Adress(); // adress van contact 
    this.cntCopy = "";  // aantal kopies dat  het contact will 
}

function ClinicalCode() {
    this.cliCode = "";  // Klinische code 
    this.cliCodingSystem = ""; // Kodeer systeem , default "MEDINA"
    this.cliCodeDsc = "";  // Omschrijving indien niet ons kodeer systeem verplicht
}

function ClinicalInfo(){
    this.cliCodes = new Array();
    this.cliComments = ""; // vrije Klinische informatie
}


function Hospitalization() {
    this.hospName = ""; // Hospital
    this.hospAdress = new Adress(); // Adres
    this.hospDepartment = ""; // Afdeling
    this.hostAdmissionRef = "";  // Opname Ref
    this.hospAdmissionDate = ""; // Opname Datum
}


