

//var iReq = new ExtRequest();
var iReq = new iLabRequest();

// Read exchange file from calling application
function readFile(fileName) {
    var txt = '';
    var xdr ;

   

    var loc = window.location.pathname;
    var dir = loc.substring(0, loc.lastIndexOf('/')) +"/" + fileName;
    //alert(dir);

    xhr = new XMLHttpRequest();
    xhr.open("GET", dir);
    xhr.send();


    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            txt = xhr.responseText;
            parseFile(txt);
             iReq.reqVersion="UC1.0";
            console.log( JSON.stringify(iReq));
            return(iReq);
        }
    };
     
}


// parse lines handle object , skipp chapter headers after setting object type
function parseFile(txt) {
    var lines;
    var objType = "UNKNOWN";
    var d = "[DOC";
    var p = "[PAT";
    lines = txt.replace(/\r\n/, "\n").split("\n");

    for (var l in lines) {
        var line = lines[l];
        var key = line.substr(0, 4);
        if (key === p) {
            //alert("got patient");
            objType = "PATIENT";
        } else if (key === d) {
            //alert("got doctor");
            objType = "PRESCRIBER";
        } else {
            parseLine(objType, line);
        }
    }
    
    
}

// parse each line 
function parseLine(typ, txt) {


    var posI = txt.indexOf("=");
    var keyWord = txt.substr(0, posI);
    var parValue = txt.substr(posI+1, txt.lenght);
    var cnt;
    parValue = parValue.replace(/\r/,"");
    
     console.log(typ + " Keyw : [" + keyWord + "] value [" + parValue + "]");
    if (parValue.length > 1) {
       
        if (typ === "PATIENT") {
            switch (keyWord) {
                case "NAME" :
                    iReq.patient.patName = parValue;
                    break;
                case "FNAME" :
                    iReq.patient.patFirstName = parValue;
                    break;
                case "GENDER" :
                    iReq.patient.patGender = parValue;
                    break;
                case "DOB" :
                    iReq.patient.patBirthDate = parValue;
                    break;
                case "ADRESS" :
                    iReq.patient.patAdress.adrStreet = parValue;
                    break;
                case "ZIP" :
                    iReq.patient.patAdress.adrZip = parValue;
                    break;
                case "CITY" :
                    iReq.patient.patAdress.adrCity = parValue;
                    break;
                case "MUT" :
                    iReq.patient.patSocSec = parValue;
                    break;
                case "TIT" :
                    iReq.patient.patTitle = parValue;
                    break;
                case "RRN" :
                    iReq.patient.patRRN = parValue;
                    break;
                case "PTEL1" :
                    cnt = new Contact();
                    cnt.cntType = "PATIENT";
                    cnt.cntProvider = "PHONE";
                    cnt.cntProviderInfo = parValue;
                    iReq.patient.patContact.push(cnt);
                    break;
                case "PTEL2" :
                    cnt = new Contact();
                    cnt.cntType = "PATIENT";
                    cnt.cntProvider = "PHONE";
                    cnt.cntProviderInfo = parValue;
                    iReq.patient.patContact.push(cnt);
                    break;
                case "PFAX" :
                    cnt = new Contact();
                    cnt.cntType = "PATIENT";
                    cnt.cntProvider = "FAX";
                    cnt.cntProviderInfo = parValue;
                    iReq.patient.patContact.push(cnt);
                    break;
                case "PEMAIL" :
                    cnt = new Contact();
                    cnt.cntType = "PATIENT";
                    cnt.cntProvider = "EMAIL";
                    cnt.cntProviderInfo = parValue;
                    iReq.patient.patContact.push(cnt);
                    iReq.patient.patEmail = parValue;
                    break;
            }
        } else if (typ === "PRESCRIBER") {
            switch (keyWord) {
                case "DNAME" :
                    iReq.prescriber.presName = parValue;
                    break;
                case "DFNAME" :
                    iReq.prescriber.presFirstName = parValue;
                    break;
                case "RIZIV" :
                    iReq.prescriber.presRegNumber = parValue;
                    break;
                case "PHONE" :
                    cnt = new Contact();
                    cnt.cntType = "PRESCRIBER";
                    cnt.cntProvider = "PHONE";
                    cnt.cntProviderInfo = parValue;
                    iReq.prescriber.presContact.push(cnt);
                    iReq.prescriber.presPhone = parValue;
                    break;
                case "FAX" :
                    cnt = new Contact();
                    cnt.cntType = "PRESCRIBER";
                    cnt.cntProvider = "FAX";
                    cnt.cntProviderInfo = parValue;
                    iReq.prescriber.presContact.push(cnt);
                    iReq.prescriber.presPhone = parValue;
                    break;
                case "EMAIL" :
                    cnt = new Contact();
                    cnt.cntType = "PRESCRIBER";
                    cnt.cntProvider = "EMAIL";
                    cnt.cntProviderInfo = parValue;
                    iReq.prescriber.presContact.push(cnt);
                    break;
                case "STREET" :
                    iReq.prescriber.presAdress.adrStreet = parValue;
                    break;
                case "ZIP" :
                    iReq.prescriber.presAdress.adrZip = parValue;
                    break;
                case "CITY" :
                    iReq.prescriber.presAdress.adrCity = parValue;
                    break;
            }
        }
    }

}
